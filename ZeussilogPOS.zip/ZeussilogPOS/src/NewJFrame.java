
import java.text.DecimalFormat;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

 
/**
 *
 * @author WAJE, Jealla Rose M. & GASPAR, Gene Zeus C.
 */
public class NewJFrame extends javax.swing.JFrame {
 
    public NewJFrame() {
        
        initComponents();
        
        jTable1.getColumnModel().getColumn(0).setPreferredWidth(30);
        jTable1.getColumnModel().getColumn(1).setPreferredWidth(200);
    }
    
    
    
    
    
    
    
    
    
    public void addtable (int id, String Name, int Qty, double Price) {
        
        DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();
        
        
        DecimalFormat df = new DecimalFormat("00.00") ;
        double totPrice = Price * Double.valueOf(Qty) ;
        
           String TotalPrice = df.format(totPrice);
         
        // not adding dish that is already inputted
        for (int row = 0;  row < jTable1.getRowCount(); row++) {
            
            if (Name == jTable1.getValueAt(row,1)) {
                dt.removeRow(jTable1.convertRowIndexToModel(row));
                 
            }
            
        }
        
        Vector v = new Vector ();
        
        v.add(id);
        v.add(Name);
        v.add(Qty);
        v.add (Price);
        v.add(TotalPrice);
        
        dt.addRow(v);
       
    }
    public void cal (){
        
        int numOfRow = jTable1.getRowCount();
        double tot = 0.0 ;
        
        for(int i = 0; i < numOfRow; i++) {
             
            double value = Double.valueOf(jTable1.getValueAt(i,4).toString());
            
            tot += value;
        }
       DecimalFormat df = new DecimalFormat("00.00") ;
       total.setText(df.format(tot));
        
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane5 = new javax.swing.JScrollPane();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jButton8 = new javax.swing.JButton();
        jButton9 = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        receipt = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        deletebButton = new javax.swing.JButton();
        payButton = new javax.swing.JButton();
        printButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        bal = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        pay = new javax.swing.JTextField();
        total = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane9 = new javax.swing.JScrollPane();
        exitButton = new javax.swing.JButton();
        addButton = new javax.swing.JButton();
        minusButton = new javax.swing.JButton();
        background = new javax.swing.JLabel();
        qty4 = new javax.swing.JLabel();
        qty2 = new javax.swing.JLabel();
        qty5 = new javax.swing.JLabel();
        qty1 = new javax.swing.JLabel();
        qty3 = new javax.swing.JLabel();
        qty6 = new javax.swing.JLabel();
        qty7 = new javax.swing.JLabel();
        qty8 = new javax.swing.JLabel();
        qty9 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Zeus Silog POS System");
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_PORKSILOG.png"))); // NOI18N
        jButton1.setAlignmentY(0.0F);
        jButton1.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 180, 180));

        jButton2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_SISIGSILOG.png"))); // NOI18N
        jButton2.setAlignmentY(0.0F);
        jButton2.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 50, 180, 180));

        jButton3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_TAPSILOG.png"))); // NOI18N
        jButton3.setAlignmentY(0.0F);
        jButton3.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 50, 180, 180));

        jButton4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_BANGSILOG.png"))); // NOI18N
        jButton4.setAlignmentY(0.0F);
        jButton4.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 270, 180, 180));

        jButton5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_CHICKSILOG.png"))); // NOI18N
        jButton5.setAlignmentY(0.0F);
        jButton5.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton5ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton5, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 270, 180, 180));

        jButton6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_BICOL EXPRESS.png"))); // NOI18N
        jButton6.setAlignmentY(0.0F);
        jButton6.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 270, 180, 180));

        jButton7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_BEEF CALDERETA.png"))); // NOI18N
        jButton7.setAlignmentY(0.0F);
        jButton7.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton7ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton7, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 490, 180, 180));

        jButton8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_PORK DINUGUAN.png"))); // NOI18N
        jButton8.setAlignmentY(0.0F);
        jButton8.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton8ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton8, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 490, 180, 180));

        jButton9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_BABY BACK RIBS.png"))); // NOI18N
        jButton9.setAlignmentY(0.0F);
        jButton9.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton9ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton9, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 490, 180, 180));

        receipt.setColumns(20);
        receipt.setRows(5);
        jScrollPane3.setViewportView(receipt);

        getContentPane().add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 50, 320, 520));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "ITEM", "QTY", "PRICE", "AMNT"
            }
        ));
        jTable1.setFocusable(false);
        jTable1.setGridColor(new java.awt.Color(0, 0, 0));
        jTable1.setShowGrid(false);
        jScrollPane2.setViewportView(jTable1);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 50, 320, 310));

        deletebButton.setBackground(new java.awt.Color(255, 51, 0));
        deletebButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        deletebButton.setForeground(new java.awt.Color(255, 255, 255));
        deletebButton.setText("DELETE");
        deletebButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deletebButtonActionPerformed(evt);
            }
        });
        getContentPane().add(deletebButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 370, 160, 30));

        payButton.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        payButton.setForeground(new java.awt.Color(255, 51, 0));
        payButton.setText("PAY");
        payButton.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED), "", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 0, 12), new java.awt.Color(255, 51, 0))); // NOI18N
        payButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payButtonActionPerformed(evt);
            }
        });
        getContentPane().add(payButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 590, 320, 110));

        printButton.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        printButton.setForeground(new java.awt.Color(255, 51, 0));
        printButton.setText("PRINT");
        printButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printButtonActionPerformed(evt);
            }
        });
        getContentPane().add(printButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 590, 320, 110));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 51, 0));
        jLabel2.setText("CHANGE :");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(670, 520, 130, 30));

        bal.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        bal.setForeground(new java.awt.Color(255, 51, 0));
        bal.setText("00");
        getContentPane().add(bal, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 520, 160, 30));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 51, 0));
        jLabel4.setText("CASH :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 480, -1, 30));

        pay.setBackground(new java.awt.Color(255, 51, 0));
        pay.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        pay.setForeground(new java.awt.Color(255, 255, 255));
        pay.setText("00");
        pay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                payActionPerformed(evt);
            }
        });
        getContentPane().add(pay, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 480, 170, 30));

        total.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        total.setForeground(new java.awt.Color(255, 51, 0));
        total.setText("00");
        getContentPane().add(total, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 440, 160, 30));

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 51, 0));
        jLabel5.setText("TOTAL :");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(700, 440, 90, 30));

        jScrollPane9.setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().add(jScrollPane9, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 420, 320, 150));

        exitButton.setBackground(new java.awt.Color(255, 51, 0));
        exitButton.setForeground(new java.awt.Color(255, 255, 255));
        exitButton.setText("EXIT");
        exitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitButtonActionPerformed(evt);
            }
        });
        getContentPane().add(exitButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(1210, 10, 120, 30));

        addButton.setBackground(new java.awt.Color(255, 51, 0));
        addButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        addButton.setForeground(new java.awt.Color(255, 255, 255));
        addButton.setText("+");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addButtonActionPerformed(evt);
            }
        });
        getContentPane().add(addButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 370, 50, 30));

        minusButton.setBackground(new java.awt.Color(255, 51, 0));
        minusButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        minusButton.setForeground(new java.awt.Color(255, 255, 255));
        minusButton.setText("-");
        minusButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                minusButtonActionPerformed(evt);
            }
        });
        getContentPane().add(minusButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(660, 370, 50, 30));

        background.setBackground(new java.awt.Color(255, 102, 0));
        background.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        background.setForeground(new java.awt.Color(255, 255, 255));
        background.setIcon(new javax.swing.ImageIcon(getClass().getResource("/z/ZS_background.png"))); // NOI18N
        background.setAlignmentY(0.0F);
        background.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                backgroundAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        getContentPane().add(background, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        qty4.setBackground(new java.awt.Color(255, 255, 255));
        qty4.setFont(new java.awt.Font("Baskerville Old Face", 1, 24)); // NOI18N
        qty4.setForeground(new java.awt.Color(255, 255, 255));
        qty4.setText("0");
        qty4.setAlignmentY(0.0F);
        getContentPane().add(qty4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 460, 30, -1));

        qty2.setBackground(new java.awt.Color(255, 255, 255));
        qty2.setFont(new java.awt.Font("Baskerville Old Face", 1, 24)); // NOI18N
        qty2.setForeground(new java.awt.Color(255, 255, 255));
        qty2.setText("0");
        qty2.setAlignmentY(0.0F);
        getContentPane().add(qty2, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 240, 30, -1));

        qty5.setBackground(new java.awt.Color(255, 255, 255));
        qty5.setFont(new java.awt.Font("Baskerville Old Face", 1, 24)); // NOI18N
        qty5.setForeground(new java.awt.Color(255, 255, 255));
        qty5.setText("0");
        qty5.setAlignmentY(0.0F);
        getContentPane().add(qty5, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 460, 30, -1));

        qty1.setBackground(new java.awt.Color(255, 255, 255));
        qty1.setFont(new java.awt.Font("Baskerville Old Face", 1, 24)); // NOI18N
        qty1.setForeground(new java.awt.Color(255, 255, 255));
        qty1.setText("0");
        qty1.setAlignmentY(0.0F);
        getContentPane().add(qty1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 240, 70, -1));

        qty3.setBackground(new java.awt.Color(255, 255, 255));
        qty3.setFont(new java.awt.Font("Baskerville Old Face", 1, 24)); // NOI18N
        qty3.setForeground(new java.awt.Color(255, 255, 255));
        qty3.setText("0");
        qty3.setAlignmentY(0.0F);
        getContentPane().add(qty3, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 240, 30, -1));

        qty6.setBackground(new java.awt.Color(255, 255, 255));
        qty6.setFont(new java.awt.Font("Baskerville Old Face", 1, 24)); // NOI18N
        qty6.setForeground(new java.awt.Color(255, 255, 255));
        qty6.setText("0");
        qty6.setAlignmentY(0.0F);
        getContentPane().add(qty6, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 460, 30, -1));

        qty7.setBackground(new java.awt.Color(255, 255, 255));
        qty7.setFont(new java.awt.Font("Baskerville Old Face", 1, 24)); // NOI18N
        qty7.setForeground(new java.awt.Color(255, 255, 255));
        qty7.setText("0");
        qty7.setAlignmentY(0.0F);
        getContentPane().add(qty7, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 680, 30, -1));

        qty8.setBackground(new java.awt.Color(255, 255, 255));
        qty8.setFont(new java.awt.Font("Baskerville Old Face", 1, 24)); // NOI18N
        qty8.setForeground(new java.awt.Color(255, 255, 255));
        qty8.setText("0");
        qty8.setAlignmentY(0.0F);
        getContentPane().add(qty8, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 680, 30, -1));

        qty9.setBackground(new java.awt.Color(255, 255, 255));
        qty9.setFont(new java.awt.Font("Baskerville Old Face", 1, 24)); // NOI18N
        qty9.setForeground(new java.awt.Color(255, 255, 255));
        qty9.setText("0");
        qty9.setAlignmentY(0.0F);
        getContentPane().add(qty9, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 680, 30, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton7ActionPerformed
      //  Beef Caldereta btn code
        int i = Integer.valueOf(qty7.getText());
        ++i;
        qty7.setText(String.valueOf(i));
        
        addtable(7, "Beef Cldrta", i, 109.00);
        cal ();
    }//GEN-LAST:event_jButton7ActionPerformed

    private void jButton9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton9ActionPerformed
//  Baby Back Ribs btn code
        int i = Integer.valueOf(qty9.getText());
        ++i;
        qty9.setText(String.valueOf(i));
        
        addtable(9, "BB back Ribs", i, 109.00);
        cal ();        
    }//GEN-LAST:event_jButton9ActionPerformed

    private void jButton8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton8ActionPerformed
         //  Pork Dinuguan btn code
        int i = Integer.valueOf(qty8.getText());
        ++i;
        qty8.setText(String.valueOf(i));
        
        addtable(8, "Pork Dinugan", i, 99.00);
        cal ();
    }//GEN-LAST:event_jButton8ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Porksilog btn code
        int i = Integer.valueOf(qty1.getText());
        ++i;
        qty1.setText(String.valueOf(i));
        
        addtable(1, "PorkSilog", i, 99.00);
        cal ();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // Sisigsilog btn code
        int i = Integer.valueOf(qty2.getText());
        ++i;
        qty2.setText(String.valueOf(i));
        
        addtable(2, "SisigSilog", i, 109.00);
        cal ();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // Tapsilog btn code
        int i = Integer.valueOf(qty3.getText());
        ++i;
        qty3.setText(String.valueOf(i));
        
        addtable(3, "TapSilog", i, 109.00);
        cal ();

    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton4ActionPerformed
        // Bangsilog btn code
        int i = Integer.valueOf(qty4.getText());
        ++i;
        qty4.setText(String.valueOf(i));
        
        addtable(4, "BangSilog", i, 109.00);
        cal ();
    }//GEN-LAST:event_jButton4ActionPerformed

    private void jButton5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton5ActionPerformed
    // Chicksilog btn code
        int i = Integer.valueOf(qty5.getText());
        ++i;
        qty5.setText(String.valueOf(i));
        
        addtable(5, "ChickSilog", i, 89.00);
        cal ();
    }//GEN-LAST:event_jButton5ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
      // Bicol Express btn code
        int i = Integer.valueOf(qty6.getText());
        ++i;
        qty6.setText(String.valueOf(i));
        
        addtable(6, "Bicol Express", i, 99.00);
        cal ();
    }//GEN-LAST:event_jButton6ActionPerformed

    private void deletebButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deletebButtonActionPerformed
       //delete button function
        DefaultTableModel dt = (DefaultTableModel) jTable1.getModel();
       
        String r = dt.getValueAt(jTable1.getSelectedRow(),0).toString();
        
        
        int rw = jTable1.getSelectedRow();
        
        //remove the product
        dt.removeRow(rw);
        
        //remove the QTY label
        System.out.println(r);
        switch (r) {
            case "1":                       
                qty1.setText("0");
                break;
            case "2":                       
                qty2.setText("0");
                break;
            case "3":                       
               qty3.setText("0");
                break;
            case "4":                       
                qty4.setText("0");
                break;
            case "5":                       
               qty5.setText("0");
                break;
            case "6":                       
                qty6.setText("0");
                break;
            case "7":                       
                qty7.setText("0");
                break;
            case "8":                       
                qty8.setText("0");
                break;
            case "9":                       
                qty9.setText("0");
                break;
            default:
                System.out.println("over");
        }
        
        cal(); // After item delete, calculate total
    }//GEN-LAST:event_deletebButtonActionPerformed

    private void payButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payButtonActionPerformed

               
               double tot = Double.valueOf(total.getText());
               double paid = Double.valueOf(pay.getText());
               double balance = paid - tot;
               
               DecimalFormat df = new DecimalFormat("00.00") ;
               
               bal.setText(String.valueOf(df.format(balance)));
             
               
    }//GEN-LAST:event_payButtonActionPerformed

    private void payActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_payActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_payActionPerformed

    private void exitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitButtonActionPerformed
        new WelcomePage().setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_exitButtonActionPerformed

    private void printButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_printButtonActionPerformed
        //printing the receipt

        try {

            receipt.setText("                                          Zeus Silog \n");
            receipt.setText(receipt.getText() + "                                Capitol Drive, Balanga, \n");
            receipt.setText(receipt.getText() + "                                2100 Bataan, Philippines \n");
            receipt.setText(receipt.getText() + "                                       0908 552 4395 \n");
            receipt.setText(receipt.getText() + "-------------------------------------------------------------------------\n");
            receipt.setText(receipt.getText() + "  Item \tQty \tPrice \t AMNT" +"\n");
            receipt.setText(receipt.getText() + "-------------------------------------------------------------------------\n");

            DefaultTableModel df = (DefaultTableModel) jTable1.getModel();

            // get table Product details

            for (int i = 0; i < jTable1.getRowCount(); i++) {

                String Name = df.getValueAt(i, 1).toString();
                String Qty = df.getValueAt(i, 2).toString();
                String Price = df.getValueAt(i, 3).toString();
                String AMNT = df.getValueAt(i, 4).toString();

                receipt.setText(receipt.getText() +"  "+ Name+"\t"+Qty +"\t"+Price + "\t"+ AMNT +"\n");
            }

            receipt.setText(receipt.getText() + "-------------------------------------------------------------------------\n");
            receipt.setText(receipt.getText() + "Sub Total : " + total.getText() +"\n");
            receipt.setText(receipt.getText() + "Cash      : " + pay.getText() +"\n");
            receipt.setText(receipt.getText() + "Balance   : " + bal.getText() +"\n");
            receipt.setText(receipt.getText() + "-------------------------------------------------------------------------\n");
            receipt.setText(receipt.getText() + "                                  Enjoy the best Silog...!"+"\n");
            receipt.setText(receipt.getText() + "-------------------------------------------------------------------------\n");
            receipt.setText(receipt.getText() + "          Software by Jealla Rose Waje & Zeus Gaspar"+"\n");

        } catch (Exception e) {}

    }//GEN-LAST:event_printButtonActionPerformed

    private void backgroundAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_backgroundAncestorAdded
        
        int selectedRow = jTable1.getSelectedRow();

        if (selectedRow != -1) {
        
            int currentQty = Integer.parseInt((String) jTable1.getValueAt(selectedRow, 2));

            currentQty++;

            jTable1.setValueAt(currentQty, selectedRow, 2);

            // Update the total price based on the new quantity
            double price = Double.parseDouble((String) jTable1.getValueAt(selectedRow, 3));
            double newTotalPrice = price * currentQty;
            jTable1.setValueAt(new DecimalFormat("00.00").format(newTotalPrice), selectedRow, 4);

            // Recalculate the total amount
            cal();
        }
    }//GEN-LAST:event_backgroundAncestorAdded

    private void minusButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_minusButtonActionPerformed
       
        int selectedRow = jTable1.getSelectedRow();

      
        if (selectedRow != -1) {
           
            int currentQty = Integer.parseInt((String) jTable1.getValueAt(selectedRow, 2));

           
            if (currentQty > 0) {
                currentQty--;
            }

          
            jTable1.setValueAt(currentQty, selectedRow, 2);

            double price = Double.parseDouble((String) jTable1.getValueAt(selectedRow, 3));
            double newTotalPrice = price * currentQty;
            jTable1.setValueAt(new DecimalFormat("00.00").format(newTotalPrice), selectedRow, 4);

        
            if (currentQty == 0) {
                ((DefaultTableModel) jTable1.getModel()).removeRow(selectedRow);
            }

         
            cal();
        }
    }//GEN-LAST:event_minusButtonActionPerformed

    private void addButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addButtonActionPerformed
        
    }//GEN-LAST:event_addButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NewJFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new NewJFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addButton;
    private javax.swing.JLabel background;
    private javax.swing.JLabel bal;
    private javax.swing.JButton deletebButton;
    private javax.swing.JButton exitButton;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JButton jButton9;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTable jTable1;
    private javax.swing.JButton minusButton;
    private javax.swing.JTextField pay;
    private javax.swing.JButton payButton;
    private javax.swing.JButton printButton;
    private javax.swing.JLabel qty1;
    private javax.swing.JLabel qty2;
    private javax.swing.JLabel qty3;
    private javax.swing.JLabel qty4;
    private javax.swing.JLabel qty5;
    private javax.swing.JLabel qty6;
    private javax.swing.JLabel qty7;
    private javax.swing.JLabel qty8;
    private javax.swing.JLabel qty9;
    private javax.swing.JTextArea receipt;
    private javax.swing.JLabel total;
    // End of variables declaration//GEN-END:variables
}
